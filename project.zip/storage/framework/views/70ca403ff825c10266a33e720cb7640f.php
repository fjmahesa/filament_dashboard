
                    <style>
                        /* Gabungkan header & toolbar tabel menjadi 1 baris flexbox */
                        .fi-ta-header-ctn {
                            display: flex !important;
                            flex-direction: row-reverse !important;
                            justify-content: space-between !important;
                            align-items: center !important;
                            gap: 1rem !important;
                            padding-bottom: 0.75rem !important;
                        }

                        /* Pindahkan input Search ke sisi KIRI */
                        .fi-ta-search-field {
                            margin-right: auto !important;
                            order: -1 !important;
                        }

                        /* Sejajarkan container tombol Export di sebelah KANAN */
                        .fi-ta-header-actions {
                            margin-left: 0 !important;
                        }
                    </style>
                <?php /**PATH /home/fajar/Projects/contact-dashboard/storage/framework/views/aaae8b4d33c86257d0a70e7878f21547.blade.php ENDPATH**/ ?>
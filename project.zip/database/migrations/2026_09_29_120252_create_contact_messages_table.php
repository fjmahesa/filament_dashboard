<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('contact_messages', function (Blueprint $table) {
        $table->id();
        $table->string('name');
        $table->string('email');
        $table->string('phone')->nullable();
        $table->string('service')->nullable();
        $table->string('subject')->nullable();
        $table->text('message');
        
        // Mengetahui asal website/projek yang mengirim pesan
        $table->string('source_website')->index()->comment('Contoh: bromo-initiative.com, wedding-app, dll.');
        
        // Status kelola pesan
        $table->enum('status', ['unread', 'read', 'replied', 'archived'])->default('unread')->index();
        
        // Informasi tracking opsional
        $table->string('ip_address')->nullable();
        $table->text('user_agent')->nullable();
        
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('contact_messages');
    }
};
